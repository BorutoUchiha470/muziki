import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:muziki/screens/albums_screen.dart';
import 'package:muziki/screens/artists_screen.dart';
import 'package:muziki/screens/playing_screen.dart';
import 'package:muziki/screens/playlists_screen.dart';
import 'package:muziki/screens/queues._screen.dart';
import 'package:muziki/screens/settings/settings_screen.dart';
import 'package:muziki/screens/storage_screen.dart';
import 'package:muziki/services/audio_player_handler.dart';
import 'package:muziki/services/library_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:muziki/utils/colors.dart';
import 'package:muziki/utils/global_variables.dart';
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Directory dir = await getApplicationDocumentsDirectory();
  Hive.init(dir.path);
  await Hive.openBox('playlists');
  await Hive.openBox('settings');
  await Hive.openBox('cache');
  await initAudioHandler();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.hbatalha.muziki.channel.audio',
    androidNotificationChannelName: 'Muziki',
    androidNotificationOngoing: true,
    androidShowNotificationBadge: true,
  );

  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Muziki',
      theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: backgroundColor),
      home: const MyApp(),
    ),
  );
}

Future<void> initAudioHandler() async {
  AudioPlayerHandler audioPlayer = AudioPlayerHandler();
  GetIt.I.registerSingleton<AudioPlayerHandler>(audioPlayer);
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _index = 1;

  List<Widget> pageViews = [];
  @override
  void initState() {
    super.initState();

    pageViews.addAll([
      QueuesScreen(swipe: swipeScreen, goToScreen: _onPageChanged),
      PlayingScreen(swipe: swipeScreen, goToScreen: _onPageChanged),
      StorageScreen(swipe: swipeScreen, goToScreen: _onPageChanged),
      AlbumsScreen(swipe: swipeScreen, goToScreen: _onPageChanged),
      ArtistsScreen(swipe: swipeScreen, goToScreen: _onPageChanged),
      PlaylistsScreen(swipe: swipeScreen, goToScreen: _onPageChanged),
    ]);

    // First launch (empty library): ask for permission and scan automatically.
    if (LibraryScanner.libraryIsEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scanLibrary());
    }
  }

  Future<void> _scanLibrary() async {
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(const SnackBar(content: Text('Scanning your music...'), duration: Duration(seconds: 3)));

    final result = await LibraryScanner.scan();
    if (!mounted) return;
    messenger.hideCurrentSnackBar();

    if (result.alreadyRunning) return;
    if (result.permissionDenied) {
      messenger.showSnackBar(SnackBar(
        content: const Text('Muziki needs permission to read your music.'),
        duration: const Duration(seconds: 8),
        action: SnackBarAction(
          label: result.permanentlyDenied ? 'SETTINGS' : 'RETRY',
          onPressed: () => result.permanentlyDenied ? openAppSettings() : _scanLibrary(),
        ),
      ));
      return;
    }
    messenger.showSnackBar(SnackBar(
      content: Text(result.songs == 0 ? 'No songs found. Add a folder in Settings > Song library.' : 'Found ${result.songs} songs'),
    ));
  }

  void _showMoreMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.refresh),
              title: const Text('Scan for music'),
              onTap: () {
                Navigator.of(sheetContext).pop();
                _scanLibrary();
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
              onTap: () {
                Navigator.of(sheetContext).pop();
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => const SettingsScreen()));
              },
            ),
          ],
        ),
      ),
    );
  }

  void _onPageChanged(int index) {
    setState(() {
      _index = index;
    });
  }

  void swipeScreen({required SwipeDirection direction}) {
    if (direction == SwipeDirection.left) {
      if (_index - 1 >= 0) {
        _onPageChanged(_index - 1);
      }
    } else if (direction == SwipeDirection.right) {
      if (_index + 1 <= 5) {
        _onPageChanged(_index + 1);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: IndexedStack(
          children: pageViews,
          index: _index,
        ),
        bottomNavigationBar: NavigationBarTheme(
          data: NavigationBarThemeData(
            backgroundColor: Colors.grey[900],
            indicatorColor: Colors.white24,
            labelTextStyle: MaterialStateProperty.all(const TextStyle(fontSize: 11, color: Colors.white)),
          ),
          child: NavigationBar(
            height: 64,
            labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
            selectedIndex: _index,
            onDestinationSelected: (int i) {
              if (i == 6) {
                _showMoreMenu();
              } else {
                _onPageChanged(i);
              }
            },
            destinations: const [
              NavigationDestination(icon: Icon(Icons.queue_music, color: Colors.white70), label: 'Queue'),
              NavigationDestination(icon: Icon(Icons.play_circle, color: Colors.white70), label: 'Playing'),
              NavigationDestination(icon: Icon(Icons.folder, color: Colors.white70), label: 'Folders'),
              NavigationDestination(icon: Icon(Icons.album, color: Colors.white70), label: 'Albums'),
              NavigationDestination(icon: Icon(Icons.person, color: Colors.white70), label: 'Artists'),
              NavigationDestination(icon: Icon(Icons.library_music, color: Colors.white70), label: 'Lists'),
              NavigationDestination(icon: Icon(Icons.more_vert, color: Colors.white70), label: 'More'),
            ],
          ),
        ),
      ),
    );
  }
}
