import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:muziki/models/song.dart';
import 'package:muziki/services/audio_player_handler.dart';
import 'package:muziki/services/library_scanner.dart';
import 'package:muziki/utils/global_variables.dart';

class StorageScreen extends StatefulWidget {
  final Function({required SwipeDirection direction}) swipe;
  final Function(int screenIndex) goToScreen;
  const StorageScreen({Key? key, required this.swipe, required this.goToScreen}) : super(key: key);

  @override
  State<StorageScreen> createState() => _StorageScreenState();
}

class _StorageScreenState extends State<StorageScreen> {
  final AudioPlayerHandler audioPlayer = GetIt.I<AudioPlayerHandler>();

  Map<String, List<Song>> _groupByFolder() {
    final folders = <String, List<Song>>{};
    for (final song in audioPlayer.songs) {
      final path = song.filePath ?? '';
      if (!path.contains('/')) continue;
      final folder = path.substring(0, path.lastIndexOf('/'));
      folders.putIfAbsent(folder, () => <Song>[]).add(song);
    }
    return folders;
  }

  String _shortName(String path) {
    return path.replaceFirst('/storage/emulated/0', 'Internal storage');
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragEnd: (dragEndDetails) {
        if (dragEndDetails.primaryVelocity != null && dragEndDetails.primaryVelocity! < 0) {
          widget.swipe(direction: SwipeDirection.right);
        } else if (dragEndDetails.primaryVelocity != null && dragEndDetails.primaryVelocity! > 0) {
          widget.swipe(direction: SwipeDirection.left);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Folders'), backgroundColor: Colors.grey[900]),
        body: ValueListenableBuilder<bool>(
          valueListenable: LibraryScanner.isScanning,
          builder: (context, scanning, _) {
            final folders = _groupByFolder();
            if (folders.isEmpty) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    scanning ? 'Scanning your music...' : 'No songs found yet.\nOpen the ⋮ menu and tap Scan.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white54, fontSize: 16),
                  ),
                ),
              );
            }
            final paths = folders.keys.toList()..sort();
            return ListView.builder(
              itemCount: paths.length,
              itemBuilder: (context, i) {
                final songs = folders[paths[i]]!;
                return ListTile(
                  leading: const Icon(Icons.folder, color: Colors.amber),
                  title: Text(_shortName(paths[i]).split('/').last),
                  subtitle: Text('${songs.length} songs • ${_shortName(paths[i])}', maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: () async {
                    await audioPlayer.updateQueue(songs, autoPlay: true);
                    widget.goToScreen(1);
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}
