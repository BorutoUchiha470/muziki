import 'dart:async';
import 'dart:io';
import 'dart:isolate';

import 'package:flutter/foundation.dart';
import 'package:flutter_isolate/flutter_isolate.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:muziki/models/song.dart';
import 'package:muziki/services/audio_player_handler.dart';
import 'package:muziki/utils/utils.dart';
import 'package:permission_handler/permission_handler.dart';

/// Result of a library scan.
class ScanResult {
  final int songs;
  final bool permissionDenied;
  final bool permanentlyDenied;
  final bool alreadyRunning;
  const ScanResult({this.songs = 0, this.permissionDenied = false, this.permanentlyDenied = false, this.alreadyRunning = false});
}

class LibraryScanner {
  static final ValueNotifier<bool> isScanning = ValueNotifier<bool>(false);

  static Future<PermissionStatus> _requestPermission() async {
    var status = await Permission.storage.status;
    if (status.isGranted) return status;
    return await Permission.storage.request();
  }

  static List<String> _defaultFolders() {
    const candidates = [
      '/storage/emulated/0/Music',
      '/storage/emulated/0/Download',
      '/storage/emulated/0/Downloads',
      '/storage/emulated/0/Podcasts',
      '/storage/emulated/0/Audiobooks',
      '/storage/emulated/0/Recordings',
      '/storage/emulated/0/Documents',
    ];
    return candidates.where((path) => Directory(path).existsSync()).toList();
  }

  /// Folders chosen by the user, or sensible defaults when none were chosen.
  static List<String> foldersToScan() {
    final saved = Hive.box('settings').get('foldersToScan', defaultValue: <String>[]);
    final folders = <String>[];
    if (saved is List) {
      for (final folder in saved) {
        folders.add(folder.toString());
      }
    }
    return folders.isNotEmpty ? folders : _defaultFolders();
  }

  static bool get libraryIsEmpty {
    final saved = Hive.box('playlists').get('allSongs', defaultValue: []);
    return saved is! List || saved.isEmpty;
  }

  static Future<ScanResult> scan() async {
    if (isScanning.value) return const ScanResult(alreadyRunning: true);

    final status = await _requestPermission();
    if (!status.isGranted) {
      return ScanResult(permissionDenied: true, permanentlyDenied: status.isPermanentlyDenied);
    }

    isScanning.value = true;
    final receivePort = ReceivePort();
    final completer = Completer<ScanResult>();
    FlutterIsolate? isolate;

    receivePort.listen((data) {
      if (data[2] == true) {
        final songs = <Song>[];
        for (final song in data[3]) {
          songs.add(Song.fromJson(Map<String, dynamic>.from(song)));
        }
        GetIt.I<AudioPlayerHandler>().refreshSongsFromScannedFolder(songs);
        if (!completer.isCompleted) completer.complete(ScanResult(songs: songs.length));
      }
    });

    try {
      isolate = await FlutterIsolate.spawn(scanSongs, [foldersToScan(), receivePort.sendPort]);
      return await completer.future.timeout(const Duration(minutes: 15), onTimeout: () => const ScanResult());
    } catch (_) {
      return const ScanResult();
    } finally {
      isolate?.kill();
      receivePort.close();
      isScanning.value = false;
    }
  }
}
